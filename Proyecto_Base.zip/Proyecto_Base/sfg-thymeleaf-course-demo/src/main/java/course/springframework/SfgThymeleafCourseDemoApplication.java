package course.springframework;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SfgThymeleafCourseDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SfgThymeleafCourseDemoApplication.class, args);
	}

}
